package com.icbc.api;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

import com.icbc.api.request.EnterPriseOpenPayPaymentRequestV1;
import com.icbc.api.request.EnterPriseOpenPayPaymentRequestV1.EnterPriseOpenPayPaymentRequestV1Biz;
import com.icbc.api.request.EnterPriseOpenPayPaymentRequestV1.EnterPriseOpenPayPaymentRequestV1Biz.EnterPriseOpenPayPaymentGoodInfo;
import com.icbc.api.request.EnterPriseOpenPayPaymentRequestV1.EnterPriseOpenPayPaymentRequestV1Biz.EnterPriseOpenPayPaymentRecInfo;


public class EnterPriseOpenPayPaymentTest {

	protected static final String MY_PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCaXN+0wqwPGjeJwL4b7pf5KVnC3ObKEkvl7N1flLpMVWRVU5CZTdwsuzyxD3Licr//J3q1dyhj27DKKtHRARFr1DjFKwnT9Umiln2bUKPmxQmIJDuH12gi3BmcAsLa2wmFlMOfSYf8dHv0Qqg139TSsPMxHVfts8ialynWy1+I2W6DUw1WxXYcS61uRAIsOaI/V4FWV3kiI5KCKPWHffspN8BJy6IgVtYJlTvZGPxxeSqRYcS3i8jOGiqBGn2KSxvoEFON4wFz0O87XUJJdWq6qlk5WQty5jU1YVRCKNfGdbQ5ZFZORaq//0A5AfU+sTor9nYpiECZshFKmCOL0Yk3AgMBAAECggEAdY918DyyvW3CDm90WeGEbIZJjlaejhcRJrMWhczHdYszNqjF33uky4xt1Itne37ZKoHuunVdlW+jXNTvprWhhvXBpqf4fCy7P9BNKRRpPz+g2sZ9cB9ld+cYufCAZh2bStjZg16E6ofsP0LkyOMHOs7459bpOGdLyDCH9MY+pAF8zxIarVuFgwXDRGYmrLPIxvQoORcEsm83BlPzx2ZWho2ycDyBtZr4CdSJMGY/nR4PqKr4ZxPpetl+RjNleUR/tX89Si5HH7fIAur8CmZ7DB5TKCz42lnhEdF/36jxT2wLF7mzowu4GATW56245cPAYKZrgIQvAwPAF+W6DHx2gQKBgQD8wpzNuc+yFZhIBBtzlEQP3ex7/cP6jOLtcTpvxj8KlcAA7GhwIO4XNO3iU02wc25oiioLuIGqndhxd/0l90GTcrfxAg1CK9WbWrlq93acgwa3PxedN3dT8yPYN/1uoDpe+2KOaWzrGvSw3Y0Zy5XC+tUQQszq+900ytKZlDx1HwKBgQCcV2NFusy4At4zlynasZd/c11nBEzEKox2/+NZ1Uy8ui42c21cfwlRC32FuuSIFlhTSewtRWM8ronkiATJNa3HrcUbJJRgTUfQJnYi9MHYQcRhUYfLqn5KXURpCS48qyYQvXguvMLxxFLSwACxKydqXgafrhviuv3BJyc6BmcQ6QKBgQC2L3hieNoR3KrkzcETr/zXCvkX7jPCdqZiy0h5pIVwFbxNbhlhKPs0UvxcM/s9ghZE18GyrQ0Zc6i9MOWQ5gWoR/n5h6cS2RGgZuZbCX+/FFpU3u8gbQhfxFND2CeeA3PPXpcNW0QculNA4JCB1VJfNfk5PU0C2wP4t3DRLh3dtQKBgAX2Ixfulo3Rti1bb0IikXdPq9kYxeCZCsAi48VyJ7nuk4KKBjqHsZBAkum9hadWyslqQTI8uhr/QMzRDvWpMVYy3xg43duKNtnODaUplhar81QOqtHuT2CAi/JBYlz33by3rNSDaB+V796PabdXwOoCadg+6FtN7A0odAt3YQi5AoGBAK8hgOogeusHyk8XCvf/gBL8VPKVSTLYoos62dqhtfRf4+nK79g9Ix3v3hQcUypNzKX2i1nckngn/L6O4/eNkZQbC1ksQV+vce/MgL4Hda24lwwf5kNhRkHk42ND0SIUQjuI5j63DsedRyzIl/04nihpWF5I/IsSeFwf2mJpt90E";

	protected static final String APIGW_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwFgHD4kzEVPdOj03ctKM7KV+16bWZ5BMNgvEeuEQwfQYkRVwI9HFOGkwNTMn5hiJXHnlXYCX+zp5r6R52MY0O7BsTCLT7aHaxsANsvI9ABGx3OaTVlPB59M6GPbJh0uXvio0m1r/lTW3Z60RU6Q3oid/rNhP3CiNgg0W6O3AGqwIDAQAB";

	protected static final String APP_ID = "10000000000000002116";
	
	@Test
	public void test_cop() throws IcbcApiException {

		// ����client����
		DefaultIcbcClient client = new DefaultIcbcClient(APP_ID, MY_PRIVATE_KEY, APIGW_PUBLIC_KEY);
	
		// �����������request
		EnterPriseOpenPayPaymentRequestV1 request = new EnterPriseOpenPayPaymentRequestV1();
		// ��������·��
		request.setServiceUrl("http://ip:port/ui//enterprise/openpay/payment/V1");
	
		EnterPriseOpenPayPaymentRequestV1Biz bizContent = new EnterPriseOpenPayPaymentRequestV1Biz();
	
		bizContent.setApi_name("OPENPAY");
		bizContent.setApi_version("001.001.002.001");
		bizContent.setFile_code("0200EG0000001");
		bizContent.setFile_name("ƽ̨����");
		bizContent.setFile_serialno("6633074382999");
		bizContent.setTradeplat_name("����ƽ̨����");
		bizContent.setTradeplat_code("773382910333");
		bizContent.setTrade_orgcode("32444324343");
		bizContent.setAcct_orgcode("43243455332");
		bizContent.setOrder_no("100000111");
		bizContent.setTrade_time("20180310162230");
		bizContent.setAmout("100");
		bizContent.setCurrtype("001");
		bizContent.setPay_name("����");
		bizContent.setPay_acct_num("6222020200012245389");
		bizContent.setPay_phoneno("010-01234567");
		bizContent.setGet_province("������");
		bizContent.setGet_city("������");
		bizContent.setGet_county("������");
		bizContent.setGet_email("zhangsan@icbc.com");
		bizContent.setGet_phone("13811112222");
		bizContent.setGet_address("�����к�����***��¥");
		bizContent.setGet_post("100101");
		bizContent.setTradeplat_rem("����ƽ̨��ע");
		bizContent.setPay_rem("���ע");
		bizContent.setOrder_rem("������ע");  
		List<EnterPriseOpenPayPaymentRecInfo> reclist = (List)new ArrayList<EnterPriseOpenPayPaymentRecInfo>();
		List<EnterPriseOpenPayPaymentGoodInfo> goodlist = (List)new ArrayList<EnterPriseOpenPayPaymentGoodInfo>();
		
		EnterPriseOpenPayPaymentRecInfo recinfo1 = new EnterPriseOpenPayPaymentRecInfo();
		EnterPriseOpenPayPaymentRecInfo recinfo2 = new EnterPriseOpenPayPaymentRecInfo();
		EnterPriseOpenPayPaymentRecInfo recinfo3 = new EnterPriseOpenPayPaymentRecInfo();
		//�տ���1
		recinfo1.setRec_seqno("1");
		recinfo1.setRec_name("����");
		recinfo1.setRec_acct_num("6222020200066551234");
		recinfo1.setRec_bnkclscode("12");
		recinfo1.setRec_orgcode("1234567890");
		recinfo1.setSystem_flag("1");
		//�տ���2
		recinfo2.setRec_seqno("2");
		recinfo2.setRec_name("����");
		recinfo2.setRec_acct_num("6222020200066551234");
		recinfo2.setRec_bnkclscode("12");
		recinfo2.setRec_orgcode("1234567890");
		recinfo2.setSystem_flag("1");
		//�տ���3
		recinfo3.setRec_seqno("3");
		recinfo3.setRec_name("����");
		recinfo3.setRec_acct_num("6222020200066551234");
		recinfo3.setRec_bnkclscode("12");
		recinfo3.setRec_orgcode("1234567890");
		recinfo3.setSystem_flag("1");
		reclist.add(recinfo1);
		reclist.add(recinfo2);
		reclist.add(recinfo3);
		
		EnterPriseOpenPayPaymentGoodInfo goodinfo1 = new EnterPriseOpenPayPaymentGoodInfo();
		EnterPriseOpenPayPaymentGoodInfo goodinfo2 = new EnterPriseOpenPayPaymentGoodInfo();
		EnterPriseOpenPayPaymentGoodInfo goodinfo3 = new EnterPriseOpenPayPaymentGoodInfo();
		
		//��Ʒ��Ϣ1
		goodinfo1.setGoods_seqno("1");
		goodinfo1.setGoods_name("��Ʒ1");
		goodinfo1.setGoods_num("100");
		goodinfo1.setWeight("��");
		goodinfo1.setPrice("1000000");
		goodinfo1.setSeller_name("����");
		goodinfo1.setSeller_address("13812345678");
		goodinfo1.setUnits("100");
		//��Ʒ��Ϣ1
		goodinfo2.setGoods_seqno("2");
		goodinfo2.setGoods_name("��Ʒ2");
		goodinfo2.setGoods_num("100");
		goodinfo2.setWeight("��");
		goodinfo2.setPrice("1000000");
		goodinfo2.setSeller_name("����");
		goodinfo2.setSeller_address("13812345678");
		goodinfo2.setUnits("100");
		//��Ʒ��Ϣ1
		goodinfo3.setGoods_seqno("3");
		goodinfo3.setGoods_name("��Ʒ3");
		goodinfo3.setGoods_num("100");
		goodinfo3.setWeight("��");
		goodinfo3.setPrice("1000000");
		goodinfo3.setSeller_name("����");
		goodinfo3.setSeller_address("13812345678");
		goodinfo3.setUnits("100");
		goodlist.add(goodinfo1);
		goodlist.add(goodinfo2);
		goodlist.add(goodinfo3);
		
		bizContent.setReclist(reclist);
		bizContent.setGoodlist(goodlist);
	
		request.setBizContent(bizContent);
	}
}
