package com.icbc.api;

import java.util.Random;

import org.junit.Test;
import com.icbc.api.request.EnterPriseOpenpayProtocalQueryRequestV1;
import com.icbc.api.request.EnterPriseOpenpayProtocalQueryRequestV1.EnterPriseOpenpayProtocalQueryRequestV1Biz;
import com.icbc.api.response.EnterPriseOpenpayProtocalQueryResponseV1;
import com.icbc.api.response.EnterpriseOpenpayControlResponseV1;
public class EnterPriseOpenpayProtocalQueryTest {


	protected static final String MY_PRIVATE_KEY = "";

	protected static final String APIGW_PUBLIC_KEY = "";

	protected static final String APP_ID = "";
	
	protected static final String password = "";
	
	protected static final  String MY_PUB_KEY = "";

	@Test 
	public void test_cop() { 

	// ����client����
	DefaultIcbcClient client = new DefaultIcbcClient(APP_ID, MY_PRIVATE_KEY, APIGW_PUBLIC_KEY,MY_PUB_KEY,password);

	
	// �����������request
	EnterPriseOpenpayProtocalQueryRequestV1 request = new EnterPriseOpenpayProtocalQueryRequestV1();
	
	// ��������·��
	request.setServiceUrl("https://gw.open.icbc.com.cn/api/enterprise/openpay/protocal/query/V1");
	
	EnterPriseOpenpayProtocalQueryRequestV1Biz bizContent = new EnterPriseOpenpayProtocalQueryRequestV1Biz();
	bizContent.setTransCode("QZJKZXY");
	bizContent.setCis("100015525000000");
	bizContent.setBankCode("102");
	bizContent.setId("eb00.y.0200");
	bizContent.setTranDate("20180315");
	bizContent.setTranTime("103022333");
	bizContent.setfSeqno("234324323244");
	bizContent.setFileCode("0200EG0000001");
	bizContent.setFileSerialNo("20180225115024");
	request.setBizContent(bizContent);
	Random rand = new Random();
	String msgId = rand.nextInt(99999)+"msg";
	
	EnterpriseOpenpayControlResponseV1 response; 
	 try { 
	  response = (EnterpriseOpenpayControlResponseV1) client.execute(request, msgId); 
	  if (response.isSuccess() ) { 
	   // ҵ��ɹ����� 
		  System.out.println("success");//
		 } else { 
		   // ʧ�� 
		  System.out.println("error");
		 }   
	 } catch (IcbcApiException e) { 
	  e.printStackTrace(); 
	 } 
	}
}
