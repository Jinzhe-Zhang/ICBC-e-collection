package com.icbc.api;

import org.junit.Test;

import com.icbc.api.internal.util.internal.util.fastjson.JSONObject;
import com.icbc.api.request.JftApiVendorInfoRegisterRequestV1;
import com.icbc.api.request.JftApiVendorInfoRegisterRequestV1.JftApiVendorInfoRegisterRequestV1Biz;
import com.icbc.api.response.JftApiVendorInfoRegisterResponseV1;

public class JftApiVendorInfoRegisterTestV1 {

	protected static final String MY_PRIVATE_KEY = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDI/Pm9FdqP7cTo+B9hQtfC9f/t5pCGSO5bmgTLAXaxEwJbL3fw91supunhtc3RrVuaeHbllWUEIWJr4lLlssHhaypiZTkgvwCEt2Nvxj3d9u0NGSO4m+grO9KaX2cO6JPHdILqavTczaHCmn/XatryEwUHoRx3X1lM30m3+MWYtJmb2ae1jKc4hI2vhHUEqmgTZyruHuLgyKwTyund3eY2Uo3Yhh5nYcitz6AraQmuSBGUIGEm1dl+REbLmrQHbr1mZ2EtO1GMrwmK692jD1G1Vx6/2PDT3Cnh6tBRLdEQaewRmafXmJbLXLNpHO1UaPINR74DZp27VfzBbeo9CV8dAgMBAAECggEBALAyPgmKmAFnUyFdK71LKPVMTWHUp8xhMTxyiFMjZFcVsBIaSg6f+nqqbwylIdr4G/8OLkVUM6tsTOkBDuU5UYh5Nz3tOSjA6QZv8qcxZlkpOGUsLcmQO/dyyUz159YFBFBtjrtMqn7Lcky0vvAtR+XB0L4AeoEXwKSIdwrl9uvHkZ9ffj5Af+2ykj6kN/tT4KIasHCtvlCqkUWHYjF+V5lxYG7p54NzF3zHDPDK0etieOiGVgBj7b9U5IMQi5zji2R5B0vZgRbY1JPHfvfeHVEVjz2hzUuC0EK5ofDOg2U4tLRKPuHMAf+fbXsoH1OilvhRTzOqYQNaogjlhSD5skECgYEA6fV5UIrCfkmhUJogrA5eVEGzXld75clUwHbBGo4BismiakXRZ8gygljXoUQF3Uu31/+ecT9NQV+BCf3qp+E1AtlNst9HQwLgsqvJ61FKSP2Mt1mIMCDVhZrIuZaQx/ZB39LTl8l0wfrHkllVIi4VhE5Bk09itTozNIgrAzC3sG0CgYEA2+xT4j0fP1Kf2V7Phz/vQ1BTh2Itct2svb/RR7VqU/LbczXoV0wF6D94suJF74Ng861iH+0M2MAoiotV+8WyziuIrSDzU4j5H0hXz0FGG/vnHaDZ7ywN6QCBJpFC7LhFRz/H6mK1F4Gx4vMNFXOXEdqzzsHtngEfMYaO8OAdG3ECgYEAtoRZQvstZgYdAdtrt65x6nti6iuHrakWJBvA4+16yIIq4YtcJQGqXcPfXKDLjmt+ndR+D80ZgPF3oorjYFqx12odUnkbh+ybzOd1282MDUs4VuVS+HD1AojRJO+QPV8g3vMDPTvdiWMSBFsKrmKTSKcgQ0LAN6+SuN2t6Iw+ETUCgYEAmqGQWYKgdeWifzQqtu49TRctpANj8V/sFX7Jp6HnIR+hLWC5/Kd3f9UhCKYQhlfZ03wVgl0qqzxxRPizfFOFZXE2qISCkjm88EHte8xpf0OfPTXcBk7zeODh7jw00jy+eVpfNm4w5lZKvUgn6u1bSzJ7OuUgLfib9jamSrdJwAECgYBl+yZnxoTmXXMvlrovQr6GJj0QeezQqsElH5u34Bbay51Ma8oZqWIvYgdN0qHEhcZND+/Vl5Kh9l+DmA+mPLvgFAbM648LAaBmubgPL2nzwolJ29OKv4C2zHpStt7Sm1h4cQQl5YGF7aB5tTfwtgOo2LtfCnh/PI/tjTs8HSZ8Lw==";	
	protected static final String APIGW_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwFgHD4kzEVPdOj03ctKM7KV+16bWZ5BMNgvEeuEQwfQYkRVwI9HFOGkwNTMn5hiJXHnlXYCX+zp5r6R52MY0O7BsTCLT7aHaxsANsvI9ABGx3OaTVlPB59M6GPbJh0uXvio0m1r/lTW3Z60RU6Q3oid/rNhP3CiNgg0W6O3AGqwIDAQAB";
	protected static final String APP_ID = "10000000000000005452";
	
	@Test
	public void test_cop() throws Exception {
		
		DefaultIcbcClient client = new DefaultIcbcClient(APP_ID,"RSA", MY_PRIVATE_KEY,"UTF-8", 
				"json",APIGW_PUBLIC_KEY,"AES","yuzLR7IMjAOZzlNZ83iXIw==", "", "");
		
		JftApiVendorInfoRegisterRequestV1 request = new JftApiVendorInfoRegisterRequestV1();
		request.setServiceUrl("http://ip:port/api/jft/api/vendor/info/register/V1");
											   
		JftApiVendorInfoRegisterRequestV1Biz bizContent = new JftApiVendorInfoRegisterRequestV1Biz();
		bizContent.setAppId("10000000000000045006");
		bizContent.setOutVendorId("RegistApiTest0006");
		bizContent.setOutUserId("RegistApiTest1006");
		bizContent.setVendorName("果果测试账号_17_04");
		bizContent.setVendorShortName("param");
		bizContent.setVendorPhone("13888888880");
		bizContent.setVendorEmail("aa@wqeq.com");
		bizContent.setProvince("119999");
		bizContent.setCity("110000");
		bizContent.setCounty("110100");
		bizContent.setAddress("北京啊啊啊是");
		bizContent.setPostcode("012340");
		bizContent.setOperatorName("测试数据1");
		bizContent.setOperatorMobile("199999999");
		bizContent.setOperatorEmail("12@qq.com");
		bizContent.setOperatorIdNo("130503670401001");
		bizContent.setVendorType("01");
		bizContent.setCorprateName("小五");
		bizContent.setCorprateMobile("166666666");
		bizContent.setCorprateIdType("01");
		bizContent.setCorprateIdNo("130503670401001");
		bizContent.setCorprateIdPic1("2018021302454400");
		bizContent.setCorprateIdPic2("img123133");
		bizContent.setCertType("02");
		bizContent.setCertNo("666455221");
		bizContent.setCertPic("img1231232");
		bizContent.setOtherCertPic1("12018032918090900587");
		bizContent.setOtherCertPic2("12018032918090900587");
		bizContent.setOtherCertPic3("12018032918090900587");
		bizContent.setAccountName("果果测试账号_17_04");
		bizContent.setAccountBankProvince("北京");
		bizContent.setAccountBankCity("北京");
		bizContent.setAccountBankNm("中国工商银行");
		bizContent.setAccountBankName("中国工商银行股份有限公司泸州分行业务处理中心");
		bizContent.setAccountBankCode("102657034111");
		bizContent.setAccountNo("0200099809214446297");
		bizContent.setAccountMobile("1383838466");
		
		
		
		request.setBizContent(bizContent);

		JftApiVendorInfoRegisterResponseV1 response;
		try {
			response =  (JftApiVendorInfoRegisterResponseV1) client.execute(request, System.currentTimeMillis()+"");
			
			System.out.println(JSONObject.toJSONString(response));
			if (response.isSuccess()) {
				// 业务成功处理
				System.out.println(response.getReturnCode());
			} else {
				//失败
			}
		} catch (IcbcApiException e) {
			e.printStackTrace();
		}


	}
	
	public static void main(String[] args) throws Exception {
		new JftApiVendorInfoRegisterTestV1().test_cop();
	}
}

