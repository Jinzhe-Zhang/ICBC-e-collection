package com.icbc.api;

import org.junit.Test;

import com.icbc.api.internal.util.internal.util.fastjson.JSONObject;
import com.icbc.api.request.JftApiVendorInfoModifyRequestV1;
import com.icbc.api.request.JftApiVendorInfoModifyRequestV1.JftApiVendorInfoModifyRequestV1Biz;
import com.icbc.api.response.JftApiVendorInfoModifyResponseV1;
import com.icbc.api.response.JftApiVendorInfoRegisterResponseV1;

public class JftApiVendorInfoModifyTestV1 {

	protected static final String MY_PRIVATE_KEY = "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDI/Pm9FdqP7cTo+B9hQtfC9f/t5pCGSO5bmgTLAXaxEwJbL3fw91supunhtc3RrVuaeHbllWUEIWJr4lLlssHhaypiZTkgvwCEt2Nvxj3d9u0NGSO4m+grO9KaX2cO6JPHdILqavTczaHCmn/XatryEwUHoRx3X1lM30m3+MWYtJmb2ae1jKc4hI2vhHUEqmgTZyruHuLgyKwTyund3eY2Uo3Yhh5nYcitz6AraQmuSBGUIGEm1dl+REbLmrQHbr1mZ2EtO1GMrwmK692jD1G1Vx6/2PDT3Cnh6tBRLdEQaewRmafXmJbLXLNpHO1UaPINR74DZp27VfzBbeo9CV8dAgMBAAECggEBALAyPgmKmAFnUyFdK71LKPVMTWHUp8xhMTxyiFMjZFcVsBIaSg6f+nqqbwylIdr4G/8OLkVUM6tsTOkBDuU5UYh5Nz3tOSjA6QZv8qcxZlkpOGUsLcmQO/dyyUz159YFBFBtjrtMqn7Lcky0vvAtR+XB0L4AeoEXwKSIdwrl9uvHkZ9ffj5Af+2ykj6kN/tT4KIasHCtvlCqkUWHYjF+V5lxYG7p54NzF3zHDPDK0etieOiGVgBj7b9U5IMQi5zji2R5B0vZgRbY1JPHfvfeHVEVjz2hzUuC0EK5ofDOg2U4tLRKPuHMAf+fbXsoH1OilvhRTzOqYQNaogjlhSD5skECgYEA6fV5UIrCfkmhUJogrA5eVEGzXld75clUwHbBGo4BismiakXRZ8gygljXoUQF3Uu31/+ecT9NQV+BCf3qp+E1AtlNst9HQwLgsqvJ61FKSP2Mt1mIMCDVhZrIuZaQx/ZB39LTl8l0wfrHkllVIi4VhE5Bk09itTozNIgrAzC3sG0CgYEA2+xT4j0fP1Kf2V7Phz/vQ1BTh2Itct2svb/RR7VqU/LbczXoV0wF6D94suJF74Ng861iH+0M2MAoiotV+8WyziuIrSDzU4j5H0hXz0FGG/vnHaDZ7ywN6QCBJpFC7LhFRz/H6mK1F4Gx4vMNFXOXEdqzzsHtngEfMYaO8OAdG3ECgYEAtoRZQvstZgYdAdtrt65x6nti6iuHrakWJBvA4+16yIIq4YtcJQGqXcPfXKDLjmt+ndR+D80ZgPF3oorjYFqx12odUnkbh+ybzOd1282MDUs4VuVS+HD1AojRJO+QPV8g3vMDPTvdiWMSBFsKrmKTSKcgQ0LAN6+SuN2t6Iw+ETUCgYEAmqGQWYKgdeWifzQqtu49TRctpANj8V/sFX7Jp6HnIR+hLWC5/Kd3f9UhCKYQhlfZ03wVgl0qqzxxRPizfFOFZXE2qISCkjm88EHte8xpf0OfPTXcBk7zeODh7jw00jy+eVpfNm4w5lZKvUgn6u1bSzJ7OuUgLfib9jamSrdJwAECgYBl+yZnxoTmXXMvlrovQr6GJj0QeezQqsElH5u34Bbay51Ma8oZqWIvYgdN0qHEhcZND+/Vl5Kh9l+DmA+mPLvgFAbM648LAaBmubgPL2nzwolJ29OKv4C2zHpStt7Sm1h4cQQl5YGF7aB5tTfwtgOo2LtfCnh/PI/tjTs8HSZ8Lw==";	
	protected static final String APIGW_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwFgHD4kzEVPdOj03ctKM7KV+16bWZ5BMNgvEeuEQwfQYkRVwI9HFOGkwNTMn5hiJXHnlXYCX+zp5r6R52MY0O7BsTCLT7aHaxsANsvI9ABGx3OaTVlPB59M6GPbJh0uXvio0m1r/lTW3Z60RU6Q3oid/rNhP3CiNgg0W6O3AGqwIDAQAB";
	protected static final String APP_ID = "10000000000000005452";
	
	@Test
	public void test_cop() throws Exception {
		
		DefaultIcbcClient client = new DefaultIcbcClient(APP_ID,"RSA", MY_PRIVATE_KEY,"UTF-8", "json",APIGW_PUBLIC_KEY,"AES","yuzLR7IMjAOZzlNZ83iXIw==", "", "");
		
		JftApiVendorInfoModifyRequestV1 request = new JftApiVendorInfoModifyRequestV1();
		request.setServiceUrl("http://ip:port/api/jft/api/vendor/info/modify/V1");
											   
		JftApiVendorInfoModifyRequestV1Biz bizContent = new JftApiVendorInfoModifyRequestV1Biz();
		bizContent.setAppId("10000000000000004473");
		bizContent.setOutVendorId("RegistApiTest0002");
		bizContent.setVendorName("测试修改接口");
		bizContent.setVendorShortName("param-1");
		bizContent.setVendorPhone("13888888881");
		bizContent.setVendorEmail("aa1@wqeq.com");
		bizContent.setProvince("119990");
		bizContent.setCity("110000");
		bizContent.setCounty("110100");
		bizContent.setAddress("北京啊啊啊是0");
		bizContent.setPostcode("000010");
		bizContent.setOperatorName("测试数据0");
		bizContent.setOperatorMobile("199999990");
		bizContent.setOperatorEmail("120@qq.com");
		bizContent.setOperatorIdNo("230702199205271133");
		bizContent.setCorprateName("zhangsan00");
		bizContent.setCorprateMobile("13666666600");
		bizContent.setCorprateIdType("0");
		bizContent.setCorprateIdNo("230702199205271133");
		bizContent.setCorprateIdPic1("2018021302454000");//key
		bizContent.setCorprateIdPic2("img12313311000");
		bizContent.setCertType("01");
		bizContent.setCertNo("66645522000");
		bizContent.setCertPic("img12312321100");
		bizContent.setOtherCertPic1("pic1121100");
		bizContent.setOtherCertPic2("pic123131100");
		bizContent.setOtherCertPic3("pic1few231100");
		bizContent.setAccountName("账户名1000");
		bizContent.setAccountBankProvince("beijin1100");
		bizContent.setAccountBankCity("bijdad11100");
		bizContent.setAccountBankNm("北京银行00");
		bizContent.setAccountBankName("啊实打实的00");
		bizContent.setAccountBankCode("bavk566100");
		bizContent.setAccountNo("ac012312100");
		bizContent.setAccountMobile("138383846600");
		bizContent.setSingleWithdrawLimit("111000");
		bizContent.setDayWithdrawLimit("222000");
		bizContent.setDayWithdrawTimes("5");
		
		request.setBizContent(bizContent);

		JftApiVendorInfoModifyResponseV1 response;
		try {
			response =  (JftApiVendorInfoModifyResponseV1) client.execute(request, System.currentTimeMillis()+"");
			
			System.out.println(JSONObject.toJSONString(response));
			if (response.isSuccess()) {
				// 业务成功处理
				System.out.println(response.getReturnCode());
			} else {
				//失败
			}
		} catch (IcbcApiException e) {
			e.printStackTrace();
		}


	}
	
	public static void main(String[] args) throws Exception {
		new JftApiVendorInfoModifyTestV1().test_cop();
	}
}

